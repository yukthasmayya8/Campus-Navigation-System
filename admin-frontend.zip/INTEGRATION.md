# Admin & Super Admin frontend (Member 4): integration notes

Drop `frontend/src/features/admin/` into the repo. It only adds files inside that folder (own CSS module, own API file, no `fetch`, no edits to shared files).

## 1. Shared-file changes to request (open issues; do not edit them yourself)
1. **`src/App.jsx`**: mount once: `<Route path="/admin/*" element={<AdminRoutes />} />` with `import { AdminRoutes } from "./features/admin";`. Needs `react-router-dom` v6. The top-bar Login link should point to `/admin/login`. (`/admin/record` redirects to `/admin/routes`; tell the team before removing `pages/AdminLogin.jsx`, `AdminHome.jsx`, `AdminRecorder.jsx`.)
2. **`src/api.js`**: the admin code assumes `api(path, { method, body })`, JSON-encodes plain-object bodies, **passes a `FormData` body through untouched** (image upload), and prepends `/api`. If yours differs, change `CONTRACT.pathPrefix` in `adminApi.js`, or request the `FormData` pass-through.
3. **Dependencies**: `react-router-dom@^6`, `leaflet` (the admin maps use plain Leaflet with their own marker icon, so no image-path setup). Optional env: `VITE_TILE_URL`.

## 2. The only file to adjust if the API differs: `adminApi.js`
GitHub blocked automated reading of the repository's code pages, so this was built from the README and the Team Guide, not from `docs/api-contracts.yaml`. Please check these assumptions against it (all live in `adminApi.js`):

| Assumption | Where |
|---|---|
| `GET /auth/me` returns `{ user }` or the user itself; fields `role`, `canRestore`, `forcePasswordChange` | `normUser` |
| Lists return `{ items }` (routes/audit also `{ total, limit, offset }`) | `items`, `usePagedList` |
| Location fields `id, name, description, latitude, longitude, imageUrl, status, versionNumber` | `normLocation` |
| Route fields `routeName, sourceLocationId, destinationLocationId, directionality, hasStairs, hasRamp, isCovered, notes, status, versionNumber, points[], waypoints[]` | `normRoute`, `routeBody` |
| Point fields `sequenceNumber, latitude, longitude, accuracy, recordedAt` | `useGpsRecorder` |
| Waypoints are **sent** as `[{ locationId, sequenceNumber }]` (`CONTRACT.waypointsAs = "ids"` sends `[locationId]`) | `CONTRACT` |
| `nearby` returns `{ items: [{ id, name, status?, distanceMeters? }] }`; `NEARBY_LOCATION` puts the same list in `details.nearby` | `LocationForm` |
| Audit entry fields `action, entityType, entityId, administratorName, timestamp, previousData, newData` (fallbacks included) | `AuditLog` |

## 3. Member 3 seam
`AdminHistory` imports `VersionHistory` and `VersionComparison` from `features/history` (merge order: history before admin) and uses the guide's contract: `VersionHistory({ entityType, entityId, canRestore, onRestore(versionNumber) })`. The guide gives no props for `VersionComparison`; it is called with `{ entityType, entityId }`: adjust that one line if Member 3 chose differently. `RestoreSnapshot` supplies the confirmation, the `expectedVersion` check (409 → conflict + Reload) and the clear resulting status.

## 4. What is covered (guide §5)
Guard (401 → login, `PASSWORD_CHANGE_REQUIRED` → change-password, other 403 → permission message) · login with no signup · forced and voluntary password change (10 chars, upper/lower/digit, server message shown) · forgot (always the same message) and reset-by-token · one `AdminDashboard` for both roles (Audit log and Accounts only for Super Admin, also guarded by route) · locations: list/filter, register with GPS capture and draggable marker, nearby check, `NEARBY_LOCATION` → "Register anyway?", `DUPLICATE_NAME`, edit/correct, deactivate (confirmed)/reactivate, image upload with client and server validation · routes: list/filter/paginate, `RouteRecorder` + `WaypointSelector` + `RoutePreview`, GPS filter (25 m / 3 m), batched upload with retry and per-point sequence numbers, save draft, publish (server message shown), discard draft (confirmed), edit metadata/waypoints, re-record replaces the path only when intended, publish/deactivate/reactivate · history restore (confirmation, conflict, resulting status, hidden-route note) · Super Admin accounts (temporary password shown once, `LAST_SUPER_ADMIN` and self-demotion messages) and audit log · every list has loading, empty, error and success states; every update sends `expectedVersion` and handles `VERSION_CONFLICT`; `null` is always shown as "Not verified".

## 5. How it was checked
- 14 unit tests (`__tests__/adminUtils.test.js`, ship with the folder): password rule, GPS filter, error messages, route adapters.
- 10 integration tests drove these exact components (React Testing Library) against a real Express + PostgreSQL backend that implements the Team Guide contract: guard and login, forced password change, Super Admin vs Admin tabs, location register/nearby/duplicate/upload/deactivate/conflict, route recording with weak and near-duplicate fixes, batch upload, waypoint, publish, discard, re-record, conflict, restore with confirmation, audit filter, temporary password shown once, permission message on a direct URL, and session loss. They are not shipped because they depend on that test backend.
- Not tested: your actual backend, a real phone's GPS, real map tiles, and Member 3's real components (stand-ins were used).
